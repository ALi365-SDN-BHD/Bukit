# Delta specialty re-review — Bukit stage 9 batch 1 (plugin test coverage)

Date: 2026-10-29
Repository: `/Users/ali/mydev/Git/Github/Bukit`
Branch: `codex/stage9` (uncommitted)
Scope: read-only delta review of the five post-specialty-v1 changes and their evidence. No repository file was modified.
Prior report: `R/reviews/specialty-v1.md`

## Verdict

- **Critical: 0**
- **Important: 1 (I-01, correctly disclosed and still open; no Core change made)**
- **Minor: 4 total open — three carried-forward Core follow-ups (M-01/M-02/M-03) plus one new cache-traceability note (D-01)**
- **No new Critical or Important finding; no new test-quality regression.**

The five changes are correctly implemented and evidenced. M-05 (DTO success/request round-trip), the loader-version part of M-04, the CI-policy diagnostic-code assertions, the `/site` flakiness note, and M-06 (final paths + baseline evidence) are all resolved. I-01 remains the only open Important finding, is accurately described in the plan, and no `src/` or other Core production file changed.

## Delta verification

### 1. DTO `Success` assertions and request/envelope round-trip (M-05) — resolved

`tests/Bukit.Plugin.Abstractions.Tests/PluginDtoSerializationTests.cs`:

- `HandshakeResponse_RoundTripsIdentityAndCollections` now asserts `Assert.True(roundTripped.Success)`.
- `ManifestResponse_RoundTripsCommandsAndPermissions` now asserts `Assert.True(roundTripped.Success)`.
- `InvokeResponse_RoundTripsErrorArtifactsAndDiagnostics` now asserts `Assert.False(roundTripped.Success)`.
- `ManifestRequestAndRequestEnvelope_SerializeProtocolShape` was renamed to `ManifestRequestAndRequestEnvelope_RoundTripProtocolShape`; it now deserializes both `PluginManifestRequest` and `PluginRequestEnvelope` and asserts `Type`, `RequestId`, and `Host.Platform` on each, in addition to the existing JSON shape checks.

This addresses the v1 weakness where a dropped `success` property would deserialize to `false` and could still pass. The true/false assertions now pin the actual values. The request test is no longer serialization-only, so the plan's "round-trip" wording is accurate. No misleading default assertion was introduced.

Verified: `R/green/abstractions-2/tests.trx` has 20/20 passed; `R/coverage/abstractions-final` reports 4986/5664 = 88.03%; the merged Abstractions figure is 4989/5664 = 88.08%. The `ManifestRequestAndRequestEnvelope_RoundTripProtocolShape` entry is present and passed.

### 2. Loader manifest-version test (part of M-04) — resolved

`tests/Bukit.PluginHost.Tests/PluginManifestLoaderTests.cs` adds:

```csharp
[Theory]
[InlineData(0)]
[InlineData(2)]
public async Task LoadAsync_UnsupportedManifestVersion_ThrowsConfigException(int manifestVersion)
```

The test writes a real `plugin.yaml` under `TestDirectory`, calls `new PluginManifestLoader().LoadAsync(...)`, and asserts `DiagnosticCode.ConfigInvalidValue` plus the loader's version message. This is the real loader path: it exercises the guard at `PluginManifestLoader.cs:33-38`, before field parsing/migration, not a direct `PluginManifestMigrator` call. It is meaningful and not tautological: 0 covers the lower bound and 2 the upper bound, and the assertion is on the actual loader diagnostic.

Verified: final PluginHost TRX is 271/271 (269 v1 + 2 theory cases), both new cases passed. PluginHost coverage increased from 1515/1777 to 1519/1777 = 85.48%; the four newly covered lines are consistent with the loader guard/message path. Baseline remains 1444/1777 = 81.26%.

### 3. CI policy diagnostic-code assertions — resolved

All four negative `PluginCiPolicy` tests now assert `DiagnosticCode.PluginExecutionFailed`: `RejectsPluginWhenAllowInCiIsFalse`, `RejectsPluginWithoutSha256InCi`, `RejectsUnverifiedSha256InCi`, and `RejectsImplicitPermissionsInCi`. The positive tests remain no-throw. This resolves the v1 weak-assertion note. No test count change; the four assertions are in the existing test cases and all pass.

### 4. `/site` flakiness note — resolved

`InvokeAsync_RejectsInvalidResponseEnvelope` now creates a `TestDirectory` and passes its path to both `CreatePlugin(...)` and `CreateInvokeRequest(...)`. The three theory cases write any execution report inside the unique temp directory instead of potentially writing under `/site`, and `TestDirectory.Dispose` removes it. This removes the environmental assumption for the changed test. No new order/culture dependence was introduced; the stub invoker still avoids process spawning. The report-writing side effect is cleaned up.

One detail: the test now exercises the real execution-report path as a side effect (the report is written but not asserted). That is acceptable for this envelope-validation test and improves cleanup; it does not mask the exception assertion because a report-writer failure would surface as a different failing exception. No new flakiness observed.

### 5. Plan record numbers, paths, and disclosures — resolved

Verified against final files:

| Claim in plan | Evidence | Result |
|---|---|---|
| PluginHost 271/271, Abstractions 20/20, 0 failed, 0 skipped | `R/green/pluginhost-4/tests.trx`, `R/green/abstractions-2/tests.trx` | correct |
| PluginHost 1519/1777 = 85.48% | `coverage/pluginhost-final2` package `Bukit.PluginHost` line rate 0.8548; unique 1519/1777 | correct |
| Abstractions own 4986/5664 = 88.03% | `coverage/abstractions-final` 4986/5664 = 0.8803 | correct |
| Abstractions merged 4989/5664 = 88.08% | union of final Abstractions and PluginHost attachments = 4989/5664 = 0.8808 | correct |
| Authored Abstractions 204/204 = 100% | handwritten DTO class line sum | correct |
| Baseline PluginHost 228/228, Abstractions 15/15 | `R/baseline/pluginhost/pluginhost.trx`, `R/baseline/abstractions/abstractions.trx` | correct |
| Baseline PluginHost 1444/1777 = 81.26% | baseline package line rate 0.8126; unique 1444/1777 | correct |
| Baseline Abstractions 2970/5664 = 52.44% | baseline top-level 2970/5664 = 0.5243 | correct (rounding) |
| Baseline merged 81.07% | union 4592/5664 = 0.81073 | correct |
| Final TRX paths `green/abstractions-2`, `green/pluginhost-4` | both directories exist and contain the cited TRX | correct |
| Final coverage paths `coverage/abstractions-final`, `coverage/pluginhost-final2` | both exist with cited attachments | correct |
| Baseline TRX/Cobertura in `R/baseline/` | both baseline directories exist | correct |
| `R/closure.json` no unmapped files | `unmappedFiles: []`; `PluginManifestLoaderTests.cs` now mapped | correct |
| `classification.json` unchanged resource classes | both projects remain `dotnet-serial`; loader path added to that group | correct |
| Status PARTIAL, no Core production change | plan text; `git status` shows only tests/docs | correct |

The plan's statement "现有实现保留输入值" is now more accurate than the v1 "实际契约" wording; the hash test still pins input-case preservation, but the plan no longer presents it as a documented contract. The plan explicitly says no three-platform CI, no full solution/release gate, and no Core fix; those scope claims are accurate.

## I-01 status (only open Important)

I-01 remains correctly disclosed in the plan:

- The plan states `PluginSecretMasker` covers only `NOTION_TOKEN`/`API_KEY`/`PASSWORD`/`TOKEN`/`SECRET`, while ADR §22.3 also forbids plaintext `COOKIE`/`Authorization` in reports.
- It states that a project granting `environment.read: ["COOKIE"]` can still cause a plaintext value in the report.
- It states the Core security fix needs separate authorization, that no production code changed, and that no failing Skip test was added.
- It states stage 9 remains PARTIAL and that "密钥掩码" can only claim the five implemented fragments, not full ADR coverage.

This is accurate. No repository Core change was made: `git status --short` and `reviews/change-v2.diff` show only the plan doc and test files; no `src/` path. The new tests do not add a `COOKIE`/`AUTHORIZATION` case, so I-01 is not accidentally hidden or falsely closed. It remains the only open Important finding.

## New delta finding

### D-01 (Minor) — Cache records use shortened command strings; literal plan commands do not hit the cache

`R/cache/*.json` records:

- tests: `dotnet test ... -c Release` (no `--logger`/`--results-directory`)
- coverage: `dotnet test ... -c Release --collect:XPlat Code Coverage` (no logger/results flags)

I reproduced `cache check` for all four records with their recorded command strings and got `CACHE HIT` for each (exit 0). The closure hashes/HEAD/SDK match the current worktree, and the records are otherwise valid.

However, the plan's "确切命令" block includes `--logger "trx;LogFileName=tests.trx"` and `--results-directory` paths. Running `cache check` with that literal command returns `CACHE MISS: command` because the cache tool compares the command string exactly. The output flags do not change test semantics, and the actual TRX/coverage evidence is green, so this is not a test-result problem. It is a traceability/process nuance: the cache records are HITs for the shortened recorded commands, not for the literal commands printed in the plan. If the workflow's exact-command rule is applied to the plan block, align the recorded command with the plan or add a note that output flags are normalized/omitted.

This is the only new Minor from the delta. It does not affect the final TRX/coverage values.

## Carried-forward Minors (not new delta findings)

The plan correctly discloses three v1 Minor follow-ups as Core work outside this tests-only batch:

- **M-01:** duplicate static argument/option names or duplicate runtime command names can throw raw `ArgumentException` instead of `ConfigException`; no production change made.
- **M-02:** `PluginHashVerifier` missing/unreadable file throws raw I/O instead of returning a failed result; no production change made.
- **M-03:** `MaskText` masks all environment values, not only secret-keyed values; contract still undecided.

These remain open but are explicitly recorded; they are not regressions and are not fixed in this batch. The platform boundary is also correctly scoped: the CLI loader's missing-current-RID branch is stage 8 CLI scope, and Windows Job Object/Linux `/proc` process-tree paths need stage 10 three-platform evidence. The low-value lock-writer cleanup/multi-entry branch remains outside this delta and is not a stage 9 blocker.

## Test-quality and flakiness check

- The loader test is a real behavioral test, not a tautology: actual `PluginManifestLoader` instance, actual YAML file, both version bounds, exact diagnostic code/message.
- The DTO success assertions now distinguish true from false; no default-false false-positive remains for handshake/manifest. The request/envelope test actually deserializes.
- The CI code assertions pin the public diagnostic code, not only a message substring.
- The changed invoke theory uses a unique temp directory and disposes it; no new `/site` write, no new process, no new global state. No order, culture, or parallel-test dependency was introduced.
- No new file/process leak observed. The temp report is removed by `TestDirectory`.
- Existing process-probe tests are untouched; the delta does not add platform-specific execution.

## Recommendation

- Accept the five delta changes: they resolve M-05, the loader-version part of M-04, the CI code assertions, the `/site` flakiness note, and M-06.
- Keep I-01 open as the sole Important item and do not mark stage 9 complete until the user authorizes a Core security task or explicitly scopes the masking claim. The plan's PARTIAL status is correct.
- Carry M-01/M-02/M-03 as disclosed Core follow-ups.
- Optionally align the cache command strings with the plan's exact commands (D-01) before reusing the cache as exact-command evidence; the test evidence itself is GREEN.

No Critical finding. One Important finding (I-01, disclosed). One new Minor (D-01), plus three carried-forward disclosed Minors.
