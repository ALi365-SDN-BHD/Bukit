# Specialty review — Bukit stage 9 batch 1 (plugin test coverage)

Date: 2026-10-29
Repository: `/Users/ali/mydev/Git/Github/Bukit`
Branch: `codex/stage9` (uncommitted)
Scope: read-only review of the test-only additions and the stage 9 plan record. No repository file was modified.

## Verdict

- **Critical: 0**
- **Important: 1**
- **Minor: 6**

The new tests are generally behaviorally meaningful: they assert protocol error codes/messages, real SHA-256 file behavior, validator diagnostics, and real DTO round-trips rather than merely restating implementation. The one Important finding is a **production secret-masking gap** surfaced by the new masker coverage: the masker does not cover `COOKIE`/`Authorization` keys that the plugin security ADR explicitly forbids recording. The six Minor findings are test-characterization, malformed-input robustness, and plan-traceability issues. Nothing in this batch requires a repository change in the tests-only scope; the Important item needs a separately authorized Core security task (or an explicit stage-9 scope decision).

No full/release gate, full solution test, or three-platform CI was run. This review did not rerun the suites; it verified the supplied TRX/coverage evidence and read the implementation.

## Evidence verified

| Item | Result |
|---|---|
| `R/green/pluginhost-3/tests.trx` | 269 total, 269 passed, 0 failed, 0 skipped |
| `R/green/abstractions/tests.trx` | 20 total, 20 passed, 0 failed, 0 skipped |
| `R/green/pluginhost/tests.trx` (first run) | 269 total, 268 passed, 1 failed — `PluginHashVerifierTests.VerifySha256Async_ComparesDigestCaseInsensitively`; failure message shows expected lowercase vs actual uppercase, matching the plan's explanation |
| PluginHost baseline arithmetic | 269 current − 41 new = 228, matches plan's baseline 228/228 |
| Abstractions baseline arithmetic | 20 current − 5 new = 15, matches plan's baseline 15/15 |
| PluginHost coverage | package `Bukit.PluginHost` line rate 0.8525; 1515/1777 = 85.26% (matches plan) |
| Abstractions own coverage | `Bukit.Plugin.Abstractions` 4983/5664 = 87.979% (matches plan) |
| Abstractions merged coverage | union with PluginHost suite = 4987/5664 = 88.047% (matches plan) |
| Abstractions authored coverage | sum of handwritten DTO classes = 204/204 = 100% (matches plan) |
| SDK | `dotnet --version` = 10.0.100, matching `global.json` and the plan |
| Diff scope | `git status` shows only the 5 modified test/doc files and 2 new test files; no `src/` changes |
| Closure/classification | `R/closure.json` has empty `unmappedFiles`; `R/classification.json` puts both test projects in `dotnet-serial` |

The plan's final counts, coverage percentages, serial execution, and "no Core production change" claim are accurate. The failing first-run TRX is retained.

## Findings

### I-01 (Important) — Secret masker misses `COOKIE`/`Authorization` keys required by the security ADR; reports can contain plaintext secrets

**Evidence**

- `src/Bukit-Core/Bukit.PluginHost/PluginSecretMasker.cs:5-12` defines only five key fragments: `NOTION_TOKEN`, `API_KEY`, `PASSWORD`, `TOKEN`, `SECRET`. `MaskValue` masks only keys containing one of those fragments (`IsSecretKey`, line 48).
- `PluginExecutionReporter` writes the plugin environment map through `MaskEnvironment` into every execution report (`PluginExecutionReporter.cs:84-90`). `MaskEnvironment` masks only fragment-matching keys (`PluginSecretMasker.cs:17-23`).
- `PluginConfigLoader` accepts arbitrary environment permission names (`PluginConfigLoader.cs:158-166`); `PluginPermissionEvaluator` rejects only `*`, not sensitive names. A project can therefore grant `environment.read: ["COOKIE"]` or `["AUTHORIZATION"]`.
- `docs/plugins/Bukit 插件安全模型 ADR.md:1350-1357` explicitly says reports must not contain plaintext `COOKIE` or `Authorization header` values; only `***` is allowed.
- The new tests do not cover this: `tests/Bukit.PluginHost.Tests/PluginSecretMaskerTests.cs:9-14` tests five fragments only; `MaskValue_LeavesNonSecretKeysUnchanged` uses `PUBLIC_VALUE` and `PLUGIN_NAME`, not `COOKIE`/`AUTHORIZATION`. The report test (`PluginLockAndReportTests.cs:143-145, 202-204`) uses only `NOTION_TOKEN` and `PUBLIC_VALUE`.

**Impact**

A plugin with `environment.read: ["COOKIE"]` (or an `AUTHORIZATION`/`HTTP_AUTHORIZATION` key) causes the value to be written verbatim into `.bukit/reports/plugin-executions/*.json` under `environment`. This violates ADR §22.3 and leaves a session cookie/authorization value in a locally persisted report. I classify it Important because it requires an explicit environment grant and writes to a local project report; if report directories are shared, archived, or committed, treat it as Critical. The new masker tests give false confidence that the "key masking" category is complete.

**Recommendation (tests-only scope: do not fix here)**

Open a separate, user-authorized Core security task. Add failing tests for `COOKIE` and `AUTHORIZATION` first (the plan's §6 rule: reproduce before KnownDefect/Skip), then extend the fragment list or replace the heuristic with an explicit contract. Update the stage 9 plan table so "five key fragments" is not presented as full ADR coverage. Do not modify the masker in this batch.

### M-01 (Minor) — Malformed command manifests can escape `ConfigException` as raw `ArgumentException`

**Evidence**

- `PluginCommandManifestValidator.cs:93` and `:118` build `ToDictionary` from static argument/option names. Duplicate names in `plugin.yaml` throw `ArgumentException` ("An item with the same key has already been added"), not `ConfigException`.
- `PluginManifestLoader.ReadArguments`/`ReadOptions` (`PluginManifestLoader.cs:187-240`) do not reject duplicate names.
- `PluginCliLoader.cs:256` similarly does `runtimeCommands.ToDictionary(...)`; a runtime manifest with duplicate command names throws `ArgumentException` in `SelectExposedCommands`, and `PluginCommandManifestValidator` does not reject duplicate runtime command names.
- The new validator tests cover duplicate *static commands* only (`PluginCommandManifestValidatorTests.cs:54-70`), not duplicate arguments/options or duplicate runtime commands.

**Impact**

A malformed but plausible `plugin.yaml` (duplicate argument or option name) or a malformed runtime manifest produces a generic exception instead of a diagnostic-coded `ConfigException`. This is not a security boundary and only affects invalid input, but it breaks the plugin error-reporting contract and is exactly the kind of gap the new "100% line" validator tests can obscure. Minor.

**Recommendation**

Add a separate test/Core task to reject duplicates with `ConfigException` (or document that duplicate names are undefined). Do not change production code in this batch.

### M-02 (Minor) — `PluginHashVerifier` missing/unreadable file behavior is untested; raw I/O exception escapes the result contract

**Evidence**

- `PluginHashVerifier.VerifySha256Async` checks empty path and expected hash, then calls `File.OpenRead(filePath)` with no catch (`PluginHashVerifier.cs`). A missing file, directory, or permission failure throws `FileNotFoundException`/`UnauthorizedAccessException` rather than returning `PluginHashVerificationResult`.
- The new tests cover empty path, empty expected hash, match, mismatch, and case-insensitivity (`PluginHashVerifierTests.cs:36-79`), but not missing/unreadable files.
- `PluginCliLoader` validates the entry path first, so the normal CLI path usually has an existing file; a TOCTOU race or direct `IPluginHashVerifier` consumer still hits this.

**Impact**

Minor robustness/diagnostic gap; not observed in the normal flow. If the contract is "return a failed result for any hash failure", this is a production defect. Add a test and decide the contract in a separate Core task.

### M-03 (Minor) — `MaskText` masks every environment value, while `MaskEnvironment` masks only secret-keyed values; the new test cannot distinguish

**Evidence**

- `PluginSecretMasker.MaskText` (`PluginSecretMasker.cs:28-44`) iterates `environment.Values` without calling `IsSecretKey`. `MaskEnvironment` (`:17-23`) does filter by key.
- `PluginSecretMaskerTests.MaskText_ReplacesLongestSecretFirst` supplies only `NOTION_TOKEN` and `API_KEY`, both secret-keyed. It would pass even if the intended contract were secret-only.
- With `PUBLIC_VALUE=visible`, `MaskText("visible", ...)` returns `***`, while `MaskEnvironment` leaves `PUBLIC_VALUE` visible. Reports/diagnostics can therefore redact benign substrings (for example a path or word equal to a non-secret env value). This is over-redaction, not a leak.

**Impact**

Minor correctness/consistency issue; possibly intentional defensive behavior. The test does not characterize the difference, so a future "fix" could change behavior without a test failing.

**Recommendation**

Decide the intended `MaskText` contract. If secret-only is intended, add a non-secret-value test and fix separately; if all values are intentionally masked, document it and add a test that pins the distinction from `MaskEnvironment`.

### M-04 (Minor) — Stage 9 exception-coverage boundaries: platform selection and loader migration gate are not directly tested; some uncovered branches are platform-specific, not macOS gaps

**Real gaps (not platform-specific)**

- **Platform selection failure:** `PluginPlatformResolverTests` has only two happy-path tests (`GetCurrentRid` returns a supported RID; the supported list is exact). The manifest-selection failure `Plugin {id} does not provide platform {rid}` in `PluginCliLoader.cs:157-160` has no test. If stage 9's "platform selection" bullet includes this CLI path (decision 5 says stage 9 is PluginHost/protocol, so it may be out of scope), the "every exception class" exit is not met. Add a `PluginCliIntegrationTests` case with a manifest lacking the fixed RID, or explicitly scope it out.
- **Manifest migration gate:** `PluginManifestLoader` rejects `manifestVersion < 1 || > 1` at `PluginManifestLoader.cs:33-38`. `PluginProtocolCompatibilityTests` tests `PluginManifestMigrator.Migrate` directly with version 99, but no loader test feeds `manifestVersion: 2` through `LoadAsync`. This bypasses the loader's own error path; add one.

**Platform-specific branches (not a macOS real gap)**

- `PluginPlatformResolver` unsupported OS/architecture `PlatformNotSupportedException` branches (lines 25/31) cannot be triggered on this host without abstraction.
- `WindowsJobProcessTreeLimiter` is 0/60 lines and Linux-specific constants 0/8 on macOS; Windows job object behavior and Linux `/proc`/process-group branches require stage 10 three-platform evidence. The plan correctly says no three-platform CI was run; it must not claim the Windows process-tree exception paths are covered.
- `PluginPathValidator` 46/57 and `PluginManifestLoader` 94/106 + 41/46 include platform/path-shape branches; the macOS tests cover traversal and symlinks. Do not count them as complete cross-platform evidence.

**Low-value uncovered branches**

- `PluginLockFileWriter` cleanup catch branches (3/7) and the multi-entry sort path are untested; the write and cancellation-preserves-lock tests cover the main behavior.

**Impact**

No Critical/Important regression. The stage 9 coverage thresholds are met; the strict "every exception class" wording is not fully evidenced for the missing-platform CLI path and the loader version gate. Distinguish these from the genuinely untestable platform branches in the final stage record.

### M-05 (Minor) — DTO round-trip tests do not assert the `success` flag; true values would pass if the property were dropped

**Evidence**

- `PluginDtoSerializationTests.HandshakeResponse_RoundTripsIdentityAndCollections` sets `Success: true` but asserts only identity/collections; `ManifestResponse_RoundTripsCommandsAndPermissions` sets `Success: true` but never asserts `roundTripped.Success`. If the source-generated serializer omitted `success`, deserialization would default to `false` and both tests would still pass.
- `InvokeResponse_RoundTripsErrorArtifactsAndDiagnostics` sets `Success: false` (the default) and does not assert it; `ResponseEnvelope_RoundTripsErrorMessagesAndDiagnostics` asserts `False` on a default-false value, which is weak.
- The protocol-client raw-JSON tests do deserialize `"success":true` and would fail if the property were not read, so the production path has some coverage; the Abstractions round-trip claim is nevertheless incomplete.
- The plan table calls the manifest request/request-envelope case a "round-trip", but `ManifestRequestAndRequestEnvelope_SerializeProtocolShape` only serializes and `Contains`-checks three fields; it does not deserialize.

**Impact**

Test-quality/coverage-claim gap, not a product defect. Add `Assert.True`/`Assert.False` for `Success` in each round-trip and either deserialize the request envelope or change the table wording to "serialization shape".

### M-06 (Minor) — Plan evidence traceability: documented commands do not name the final TRX/coverage artifacts, and baseline claims have no baseline evidence in `R`

**Evidence**

- The plan's command block writes PluginHost green TRX to `$R/green/pluginhost-2` and coverage to `$R/coverage/pluginhost`. The task's final evidence is `$R/green/pluginhost-3/tests.trx` and `$R/coverage/pluginhost-final`; both `pluginhost` and `pluginhost-final` have the same line rate 0.8525, and both `pluginhost-2` and `pluginhost-3` are 269/269, so the numbers are reproducible, but the documented command is not the exact final artifact.
- The failing first run is retained at `$R/green/pluginhost/tests.trx`, but the command block does not show how it was produced; the plan says "原始 TRX 保留" without a command/path distinction.
- Baseline claims (228/228, 15/15, 81.26%, 52.44%, merged 81.07%) have no baseline TRX/coverage in `R`; only final artifacts are present. The arithmetic is consistent, but the baseline is not independently traceable from this evidence root.
- `实际契约保留输入值` for `ExpectedSha256` is inferred from implementation; no public doc/schema states case preservation. The test now pins that behavior (`PluginHashVerifierTests.cs:76`).

**Impact**

Documentation/traceability, not execution correctness. The final counts, coverage, serial classification, and "no Core change" claim are accurate; the plan does not overclaim platform/CI evidence and does not claim a Core fix. Update the command paths/notes so a reader can reproduce the exact final TRX/coverage, and label baseline numbers as historical unless a baseline evidence path is added.

## Stage 9 exception inventory

| Category | Covered by existing/new tests | Residual gap |
|---|---|---|
| Manifest loading/migration | 7 `PluginManifestLoaderTests` (protocol/kind/id, wildcard env, external distribution, unsafe FS paths); 2 migrator tests | `manifestVersion` loader gate, missing/empty manifest, root/platform-shape errors not direct; same `ConfigException` codes |
| Platform selection | 2 `PluginPlatformResolverTests` happy path | CLI missing-platform `ConfigException` untested; unsupported OS/arch throws platform-specific/unreachable on macOS |
| Hash/path | 5 hash tests (match/mismatch/empty path/empty expected/case); 6 path tests (traversal/symlink) | Missing/unreadable file throws raw I/O; Windows path-shape branches platform-specific |
| Permission | 8 evaluator tests; wildcard covered in loaders; 100% lines | Argument/null-input checks not directly tested (low risk) |
| Env clearing/whitelist | `SystemProcessRunnerTests` parent-env-not-inherited and explicit-env; permission evaluator env subset; CLI end-to-end mask test | Private `CreateAllowedEnvironment` not directly tested; generated report env map is the leak path in I-01 |
| Secret masking | 6 new tests, five fragments, non-secret, null, env, longest-first, empty; 100% lines | `COOKIE`/`AUTHORIZATION` missing (I-01); `MaskText` non-secret behavior (M-03) |
| Protocol v1 normal/exception | Handshake normal + type/failure/identity/protocol/requestId; manifest normal + type/failure/empty/invalid JSON/exit; invoke normal + type/protocol/requestId/timeout/output/resource/artifact/exit; real probe timeout/garbage/invalid UTF-8/oversize/exit 7 | Signal/abnormal termination probe deferred per plan; Windows job-object tree paths not executed |
| Lock/report | Lock write + cancellation preserves old lock; reporter golden + schema + masking; 6 CI-policy tests covering all four branches | Lock cleanup catch branches and multi-entry sort untested |
| CI policy | `!isCi`, allowInCi false, missing sha, unverified sha, implicit permissions, valid CI | Tests assert message fragments, not `DiagnosticCode` (minor) |
| Abstractions DTOs | 10 tests; all six response/request types now 100% own-suite lines | `success` flag not asserted in round-trips (M-05) |

## Test quality, flakiness, and leakage

- **Meaningful tests:** The new manifest-validator tests assert exact `DiagnosticCode` values and diagnostic substrings, including nested paths. Protocol tests assert exact error messages via `AssertProtocolFailure` and isolate each validation branch. Hash tests use real files and real SHA-256. DTO tests round-trip non-default data. These are not tautological.
- **Over-fitting:** The hash case-insensitivity test pins `ExpectedSha256` case preservation (M-06); the CI-policy tests assert message fragments rather than codes; the DTO `success` assertions are weak (M-05).
- **Flakiness:** No new order dependence, culture dependence, or process spawning in the new tests. `PluginHashVerifierTests` uses unique temp directories and disposes them. `PluginProtocolClientTests` uses stubs. The only environmental assumption is the pre-existing `CreateInvokeRequest` root `/site`; the new invoke-envelope cases call `InvokeAsync`, which writes an execution report only if `/site` exists. On a machine where `/site` exists, those tests would attempt to write there. Low risk, but using `TestDirectory` for invoke tests would remove it.
- **File/process leaks:** No new process leaks; the process-probe tests are existing. No new file leaks observed; lock/report tests use temp directories.
- **Coverage caveat:** The 85.26% PluginHost number includes platform-specific process-tree code; the 87.98% Abstractions number is dominated by generated `JsonSerializerContext` code. The plan's 204/204 authored figure is the honest supplementary metric.

## Plan doc accuracy

Verified accurate:

- 269/269 PluginHost and 20/20 Abstractions, zero failures/skips.
- First run 268/269 with the hash-test assertion failure; original TRX retained.
- PluginHost 1515/1777 = 85.26%; Abstractions 4983/5664 = 87.98%; authored 204/204; merged 4987/5664 = 88.05%.
- Serial Abstractions → PluginHost execution; closure has no unmapped files.
- No Core production code changed; no full/release/full-solution/three-platform CI claimed.
- The plan does not claim a Core fix or platform evidence it did not obtain.

Needs correction/clarification:

- Command paths point to `pluginhost-2`/`coverage/pluginhost` rather than the final `pluginhost-3`/`coverage/pluginhost-final` (both green/identical; traceability only).
- Table says "round-trip" for the manifest request/request-envelope test; that test only serializes.
- "Five key fragments" is accurate for the code but incomplete against ADR §22.3 (`COOKIE`/Authorization); see I-01.
- Baseline coverage claims lack a baseline TRX/XML path in `R`.
- "Actual contract preserves the input value" for `ExpectedSha256` is an implementation observation, not a documented contract.

## Recommendation

- Do not modify the repository for I-01 in this tests-only batch. Record it as a stage 9 blocker decision: either open a separate Core security task (preferred, with a failing `COOKIE`/`AUTHORIZATION` test first) or explicitly scope the masking claim to the five implemented fragments and disclose the ADR gap. If the security model is binding, the stage 9 exit should not be marked complete for "secret masking" until fixed.
- Treat M-01/M-02 as follow-up Core robustness tasks, not batch-1 changes.
- Accept the new tests as behaviorally meaningful; the remaining Minor items are test-quality/doc traceability improvements and do not require rerunning the green evidence.
- Before stage 9 exit, add the missing platform-selection and loader-version tests or record them as explicit scope exclusions, and distinguish them from the genuinely platform-specific Windows/Linux branches.

No Critical finding. One Important finding (I-01). Six Minor findings.
