# I-01 final delta-only review — plugin secret masking (`COOKIE` / `AUTHORIZATION`)

- Repository: `/Users/ali/mydev/Git/Github/Bukit`
- Branch: `codex/stage9` (uncommitted); HEAD `7a8b71350501ded16a5268b6bb7cef23afd6aa67`
- Evidence root `R2`: `/private/var/folders/f6/1xdrtq9j7030l4ww_sgnr0pw0000gn/T/opencode/stage9-plugin-secret-masker-20261029`
- Review mode: read-only. No repository file was modified. `dotnet test` was **not** rerun; the recorded TRX, logs, Cobertura, cache records and file hashes were verified directly. The specialty review `R2/reviews/specialty-v1.md` was reused.
- Scope: generated `R2/review-scope.json` reports no cross-task intersections, no invalidated evidence, no uncovered changed files and no open blocking findings. Public-contract focus is `src/Bukit-Core/Bukit.PluginHost/PluginSecretMasker.cs`.

## Verdict

**ACCEPT for I-01.** The production change is exactly the two-fragment extension to `PluginSecretMasker.SecretKeyFragments`, and it closes I-01 for the host-controlled report paths (environment, stderr, diagnostics message/path, artifact description). No other production/report path writes plaintext values for keys containing `COOKIE` or `AUTHORIZATION`.

**Stage 9 may be marked SUCCESS with this task's evidence.** The only open Important from stage 9 (I-01) is closed; S-01 is correctly disclosed as a pre-existing, non-blocking follow-up; M-01/M-02/M-03 and the deferred true-crash probe remain out of scope. Before closing the evidence package, complete the bookkeeping listed under “Stage 9 judgment” below.

- Critical: **0**
- Important: **0**
- Minor: **2** — S-01 (open, carry-forward, non-blocking) and S-03 (new, evidence-completeness, non-blocking). S-02 is resolved.

## 1. Production change and I-01 closure

### Exact change

`git diff` for the production file is exactly two added strings; no other production file is modified:

```diff
@@ -7,6 +7,8 @@ internal static class PluginSecretMasker
         "NOTION_TOKEN",
         "API_KEY",
         "PASSWORD",
+        "COOKIE",
+        "AUTHORIZATION",
         "TOKEN",
         "SECRET"
```

- Current file hash: `a0ab3596ac97213e766c1f1b7ab530270e029086ed71295998400fff53c8e419`
- The hash matches both cache records and the closure fingerprint inputs.
- `IsSecretKey` uses `StringComparison.OrdinalIgnoreCase` and substring matching (`PluginSecretMasker.cs:49-50`), so `COOKIE`, `HTTP_COOKIE`, `SET_COOKIE`, `AUTHORIZATION`, `HTTP_AUTHORIZATION` and `PROXY_AUTHORIZATION` are all covered; lowercase `cookie` is covered by test.
- Existing `NOTION_TOKEN`, `API_KEY`, `PASSWORD`, `TOKEN`, `SECRET` behavior is unchanged. Non-secret keys remain visible; null/empty handling is unchanged.

### Reporter audit

`PluginExecutionReporter` is the only production consumer of `PluginSecretMasker` and the only writer of plugin execution reports.

| Report path | Code | Result |
|---|---|---|
| `stderr` | `MaskText(report.Stderr, report.Environment)` (`:84`) | **Closed** — raw environment is passed to `MaskText`, so cookie/authorization values are replaced with `***`. |
| `environment` | `MaskEnvironment(report.Environment)` (`:87`) | **Closed** — new fragments produce `***` for matching keys, including `HTTP_*`. |
| `diagnostics[].message` | `MaskText` (`:168`) | **Closed**. |
| `diagnostics[].path` | `WriteNullableMaskedString` → `MaskText` (`:169`, `:117-130`) | **Closed**. |
| `artifacts[].description` | `WriteNullableMaskedString` → `MaskText` (`:187`) | **Closed**. |
| `permissions.environment.read` | key names only (`:149-153`) | Correctly visible; these are names, not values. |
| `artifacts[].path` / `artifacts[].type` | raw (`:185-186`) | **S-01** — pre-existing plugin-controlled residual. |
| `diagnostics[].code` | raw (`:166`) | **S-01** — pre-existing plugin-controlled residual. |
| `responseSummary.diagnosticCodes` | raw (`:205-206`) | **S-01** — pre-existing plugin-controlled residual. |

The report-level test `PluginExecutionReporter_MasksCookieAndAuthorizationValues` exercises the real `WriteAsync`, reads the written JSON and asserts:

```csharp
Assert.Contains("\"COOKIE\": \"***\"", json, StringComparison.Ordinal);
Assert.Contains("\"HTTP_AUTHORIZATION\": \"***\"", json, StringComparison.Ordinal);
Assert.DoesNotContain("session-cookie", json, StringComparison.Ordinal);
Assert.DoesNotContain("raw-token", json, StringComparison.Ordinal);
```

Because the same strings appear in `Stderr`, the test also proves the `MaskText` path, not just `MaskEnvironment`. The existing golden report test still asserts `PUBLIC_VALUE` visibility and `NOTION_TOKEN` masking.

No other report writer exists: repository search finds no other `PluginExecutionReport` writer or `MaskEnvironment`/`MaskText` call site. The report schema, public API, permissions model and CLI are unchanged. Over-masking of keys such as `COOKIE_ENABLED` or `AUTHORIZATION_MODE` is confined to reports and is explicitly accepted by the proposal as preferable to a leak.

## 2. Evidence verification

### RED

`R2/red/tests.trx`:

- 28 executed, 21 passed, **7 failed**, 0 skipped, 0 errors.
- Failed cases are exactly the new behavior:
  - `MaskValue_MasksSecretKeyFragments` for `COOKIE`, `HTTP_COOKIE`, `AUTHORIZATION`, `HTTP_AUTHORIZATION`, `cookie` (5);
  - `MaskEnvironment_MasksOnlySecretKeys` (1);
  - `PluginExecutionReporter_MasksCookieAndAuthorizationValues` (1).
- Failure messages are assertion failures (`Assert.Equal` strings differ; `Assert.Contains` sub-string not found), not compile/load errors. The existing report-masking test passed in RED, so the old contract was preserved while the new behavior was absent.
- Test-first ordering is supported by mtimes: masker test file `22:10:26`, report test file `22:10:45`, RED TRX `22:10:55`, production file `22:10:59`, focused GREEN `22:11:09`, full GREEN `22:11:25`.

### GREEN

| Run | Result | Evidence |
|---|---|---|
| Focused `PluginSecretMaskerTests|PluginLockAndReportTests` | **28/28 passed**, 0 failed, 0 skipped | `R2/focused-green/tests.trx` |
| Full PluginHost | **277/277 passed**, 0 failed, 0 skipped | `R2/green/tests.trx` |
| Coverage run | **277/277 passed**; 277 executed | `R2/coverage/tests.trx` |

The full run includes all five new theory cases, the lowercase `cookie` case, the extended `MaskEnvironment` test and the new report test. The +6 tests versus the stage 9 batch’s 271 are exactly the five new theory cases plus one new report Fact; the modified `MaskEnvironment` test was already counted in the 271.

### Coverage arithmetic

From `R2/coverage/d87e8f60-ff68-4df0-8ce3-674f630c424d/coverage.cobertura.xml` (the TRX-referenced attachment; the duplicate `_ALideMacBook-Pro-4...` file has the same timestamp/root counters and is the collector’s same-run copy):

- `Bukit.PluginHost`: **1521 / 1779 = 85.50%** (computed 85.4975%); up exactly 2 covered and 2 total lines from the stage 9 batch’s **1519 / 1777 = 85.48%**.
- `PluginSecretMasker.cs`: **25 / 25 lines covered**, including both new fragment lines.
- `Bukit.Plugin.Abstractions`: unchanged **4986 / 5664 = 88.03%** own and **4989 / 5664 = 88.08%** merged; authored 204/204 = 100%.
- `R2/coverage-summary.json` records the same values; the arithmetic above is internally consistent.

### Cache HITs

Both records were checked with the exact recorded commands, HEAD, SDK `10.0.100`, the three closure paths and current file hashes:

```sh
python3 scripts/checks/codex-workflow.py cache check \
  --record "$R2/cache/pluginhost-tests.json" \
  --base 7a8b71350501ded16a5268b6bb7cef23afd6aa67 \
  --command 'dotnet test tests/Bukit.PluginHost.Tests/Bukit.PluginHost.Tests.csproj -c Release --logger "trx;LogFileName=tests.trx" --results-directory "'$R2'/green"' \
  --sdk-version 10.0.100 \
  --path src/Bukit-Core/Bukit.PluginHost/PluginSecretMasker.cs \
  --path tests/Bukit.PluginHost.Tests/PluginLockAndReportTests.cs \
  --path tests/Bukit.PluginHost.Tests/PluginSecretMaskerTests.cs
# -> CACHE HIT 609126375e4cb8df1b9e3f139807ba1b443e42ed33a24a16ae535352181fe068

python3 scripts/checks/codex-workflow.py cache check \
  --record "$R2/cache/pluginhost-coverage.json" \
  --base 7a8b71350501ded16a5268b6bb7cef23afd6aa67 \
  --command 'dotnet test tests/Bukit.PluginHost.Tests/Bukit.PluginHost.Tests.csproj -c Release --collect:"XPlat Code Coverage" --logger "trx;LogFileName=tests.trx" --results-directory "'$R2'/coverage"' \
  --sdk-version 10.0.100 \
  --path src/Bukit-Core/Bukit.PluginHost/PluginSecretMasker.cs \
  --path tests/Bukit.PluginHost.Tests/PluginLockAndReportTests.cs \
  --path tests/Bukit.PluginHost.Tests/PluginSecretMaskerTests.cs
# -> CACHE HIT 0a8a28367da26007102f6f18948a14c2fbdb0904f84b754cb3d6bce191d13992
```

Current SHA-256 values match the records:

- `PluginSecretMasker.cs`: `a0ab3596...c8e419`
- `PluginLockAndReportTests.cs`: `870038a7...d45df8`
- `PluginSecretMaskerTests.cs`: `d358a9a4...c2600f9`

### Closure and diff completeness

- `R2/closure.json`: no unmapped files; direct consumer `PluginExecutionReporter.cs`; specialty command `dotnet test tests/Bukit.PluginHost.Tests/Bukit.PluginHost.Tests.csproj` classified `dotnet-serial`; changed files are the masker, the two test files, the plan and the three OpenSpec records.
- `R2/review-evidence.json`: 24 closure files, public-contract focus `PluginSecretMasker.cs`, cache status `hit`.
- `R2/reviews/final.diff` contains **9 files** and includes the previously missing untracked `PluginSecretMaskerTests.cs`; the extracted content hashes to `d358a9a4...c2600f9`, exactly matching the worktree. **S-02 is resolved.**
- `git diff --check` is clean.
- **S-03:** `final.diff` still omits the three untracked OpenSpec files (`proposal.md`, `tasks.md`, `specs/plugin-secret-masking/spec.md`). They are present in the worktree and in `closure.json`/`review-evidence.json`, so the evidence is verifiable; the consolidated diff is not a complete delta. This is a non-blocking evidence-completeness issue; regenerate the diff or append those three files before archiving if `final.diff` is the audit artifact.

## 3. OpenSpec and plan accuracy

- `openspec/changes/fix-plugin-secret-masker-cookie-authorization/proposal.md` accurately describes the authorized scope: mask environment values for `COOKIE`/`AUTHORIZATION` (including `HTTP_*`) in plugin execution reports; keep existing fragments, non-secret visibility, null handling and report schema; no public API, option, dependency, schema, permissions or CLI change; no commit/push/broad gate. The worktree matches this description.
- `specs/plugin-secret-masking/spec.md` matches the implementation: key-based, case-insensitive, includes `HTTP_COOKIE`/`HTTP_AUTHORIZATION`, preserves existing fragments and non-secret visibility. Its “environment keys” wording does not overclaim coverage of plugin-controlled fields; S-01 remains outside it.
- `tasks.md` checks tasks 1 and 2 with accurate RED/GREEN/coverage/cache claims; task 3 remains unchecked because it owns this final review and the post-review backfill. That is expected bookkeeping, not a false success claim.
- The stage 9 plan has an I-01 record and a KD-013 row. Both are consistent with the evidence: two-fragment change, RED 7/21, focused 28/28, full 277/277, coverage 85.50%, schema/API/permissions unchanged, S-01 disclosed, S-02 resolved. The plan explicitly retains no claim of three-platform CI, full/release gate, commit, push or merge.
- The older stage 9 batch row that says the masker test covered “five fragments” is historically accurate for that batch; the later I-01 section explicitly states the current seven-fragment coverage. No correction is required, though a “five at the time; seven after I-01” clarification would read more cleanly.
- The plan still says the stage 9 final judgment awaits this review (`阶段 9 最终判定需待本任务唯一 delta-only 最终复核完成后回填`). That is accurate at review time; after this review the controller should update the status and line 1299, check task 3 and record metrics.
- Note, not a finding: `openspec validate fix-plugin-secret-masker-cookie-authorization --strict` reports “No delta sections found” because the spec uses `## Requirement:` rather than `## ADDED Requirements`. The same format is used by existing recent changes such as `fix-kd002-clean-metadata-retention`, and no CI OpenSpec validation is wired for this change (the only policy mapping is for an archived i18n change); this is a repository-wide format convention, not an I-01 regression.

## 4. Cross-task and public-contract impact

No new cross-task or public-contract implication was found.

- `PluginSecretMasker` remains internal; no public type, member, signature or exported API changed.
- The report schema, field set, version and bytes for reports without `COOKIE`/`AUTHORIZATION` keys are unchanged; only matching environment values and free text containing those granted values change to `***`.
- The permissions model and `environment.read` key-name visibility are unchanged.
- No CLI, Engine, protocol or config behavior is touched.
- No other test project consumes the masker; the architecture internalization test still sees an internal type.
- The phase-0 evidence workflow pins historical source hashes, but it is branch-scoped to `evidence/core-phase0-20261025` and is not triggered by `codex/stage9`; no gate was run or invalidated.

## 5. Out-of-scope items confirmed

- **S-01:** `PluginExecutionReporter` still writes plugin-controlled `artifacts[].path`, `artifacts[].type`, `diagnostics[].code` and `responseSummary.diagnosticCodes` raw. A plugin that deliberately echoes an already-granted secret into one of those fields can still place plaintext in the report. This is pre-existing, applies equally to the old fragments, is outside the authorized key-fragment scope, and is correctly a non-blocking follow-up for a separate Core task. It does not invalidate I-01.
- **M-01/M-02/M-03:** duplicate argument/option/runtime-command names can still throw raw `ArgumentException`; `PluginHashVerifier` can still throw raw I/O for missing/unreadable files; `MaskText` still masks all environment values rather than only secret-keyed values. No production diff changes the M-01/M-02 paths; the I-01 diff only adds fragments to the masker list and does not change `MaskText`, so M-03 is neither fixed nor worsened.
- **True-crash probe:** still deferred to the post-stage summary; the I-01 tests are masker/report tests and do not touch process/probe classes. The existing `exit 7` crash case remains the stage 9 evidence.
- **Gates/commit:** no full solution test, complete coverage gate, release gate or three-platform CI was run; no commit, push or merge was made.

## Findings

### Critical

None.

### Important

None.

### Minor

**S-01 — Pre-existing plugin-controlled report fields bypass text masking (open, carry-forward, non-blocking).**
`PluginExecutionReporter` masks `stderr`, diagnostic messages/paths and artifact descriptions, but writes `artifacts[].path` (`:186`), `artifacts[].type` (`:185`), `diagnostics[].code` (`:166`) and `responseSummary.diagnosticCodes` (`:205-206`) raw. A plugin that echoes a granted `COOKIE`/`AUTHORIZATION` value into one of those fields can still put plaintext in the report. This is not introduced by I-01, applies equally to the existing fragments, is outside the authorized key-fragment scope, and is correctly scheduled as a separate Core follow-up. Do not expand I-01 to fix it.

**S-03 — `R2/reviews/final.diff` omits the three untracked OpenSpec files (new, non-blocking).**
The diff includes the untracked masker test and the other code/test/plan changes, but not `openspec/changes/fix-plugin-secret-masker-cookie-authorization/{proposal.md,tasks.md,specs/plugin-secret-masking/spec.md}`. Those files are in the worktree, `closure.json` and `review-evidence.json`, and their content was reviewed; only the consolidated diff artifact is incomplete. Regenerate `final.diff` (or append the three files) before archiving if it is the audit artifact. No code change required.

### Resolved

**S-02 — initial `i01.diff` omitted the untracked masker test file.** Resolved: `final.diff` includes `PluginSecretMaskerTests.cs`; the extracted content hash matches the worktree. `i01.diff` remains an intermediate artifact and is superseded by `final.diff`.

## Stage 9 judgment

I-01 is closed for the authorized scope. The only open Important from the stage 9 batch is now closed, and S-01 is a correctly disclosed, pre-existing, non-blocking follow-up. **Stage 9 may be marked SUCCESS with this task's evidence.** The stage 9 batch `findings.json` still records I-01 as open at that time; it is historical evidence, not the current status. The stage 9 I-01 record, KD-013 and this review supersede it.

Required closing bookkeeping (no code/test change):

1. Update the stage 9 plan status at line 1252 and the final-judgment line 1299 to record this final review and SUCCESS; keep the historical “I-01 was open before the authorized fix” record.
2. Check `tasks.md` item 3, run `git diff --check` again if any file is touched during bookkeeping, and record the required metrics.
3. Regenerate `final.diff` to include the OpenSpec files (S-03) before archiving, if the consolidated diff is the audit artifact.
4. Do not commit, push, merge, run a full/release gate or claim three-platform CI. Do not mark S-01, M-01/M-02/M-03 or the true-crash probe as fixed.

## Commands and evidence reviewed

Recorded test commands (not rerun by this read-only review):

```sh
dotnet test tests/Bukit.PluginHost.Tests/Bukit.PluginHost.Tests.csproj -c Release \
  --logger "trx;LogFileName=tests.trx" \
  --results-directory "$R2/green"
# -> 277 passed / 0 failed / 0 skipped

dotnet test tests/Bukit.PluginHost.Tests/Bukit.PluginHost.Tests.csproj -c Release \
  --collect:"XPlat Code Coverage" \
  --logger "trx;LogFileName=tests.trx" \
  --results-directory "$R2/coverage"
# -> 277 passed; PluginHost 1521/1779 = 85.50%
```

Read-only verification performed:

```sh
git rev-parse HEAD                                  # 7a8b7135...
git diff --check                                    # clean
shasum -a 256 <masker and two test files>           # matches cache records
python3 scripts/checks/codex-workflow.py cache check ...   # 2/2 CACHE HIT
# TRX counters and failed-test names parsed from R2/{red,focused-green,green,coverage}/tests.trx
# Cobertura counters parsed from the TRX-referenced coverage.cobertura.xml
```

Key evidence files:

- `R2/reviews/specialty-v1.md` — accepted specialty review, Critical 0 / Important 0 / Minor 2.
- `R2/red/tests.trx`, `R2/red/tests.log` — behavioral RED.
- `R2/focused-green/tests.trx`, `R2/green/tests.trx`, `R2/coverage/tests.trx` — GREEN.
- `R2/coverage/d87e8f60-ff68-4df0-8ce3-674f630c424d/coverage.cobertura.xml` — coverage.
- `R2/cache/pluginhost-tests.json`, `R2/cache/pluginhost-coverage.json` — cache records.
- `R2/closure.json`, `R2/review-evidence.json`, `R2/review-scope.json` — scope.
- `R2/reviews/final.diff` — code/test/plan delta (S-03 gap noted).
- `openspec/changes/fix-plugin-secret-masker-cookie-authorization/` — proposal, tasks, spec.
- `docs/plans/bukit-core-automated-test-plan-2026-10-24.zh-CN.md` — stage 9 I-01 record and KD-013.
