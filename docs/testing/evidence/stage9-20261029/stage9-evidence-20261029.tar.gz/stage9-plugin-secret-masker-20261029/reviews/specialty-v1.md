# I-01 specialty review — plugin secret masking (`COOKIE` / `AUTHORIZATION`)

- Repository: `/Users/ali/mydev/Git/Github/Bukit`
- Branch: `codex/stage9` (uncommitted); HEAD `7a8b71350501ded16a5268b6bb7cef23afd6aa67`
- Evidence root: `R=/private/var/folders/f6/1xdrtq9j7030l4ww_sgnr0pw0000gn/T/opencode/stage9-plugin-secret-masker-20261029`
- Review mode: read-only; no repository files modified, no `dotnet test` rerun (TRX, logs, hashes and cache records verified).

## Verdict

**ACCEPT for I-01.** The production change is the minimal two-fragment extension to `PluginSecretMasker.SecretKeyFragments`; it correctly closes the authorized gap for `COOKIE`/`AUTHORIZATION` environment values in `PluginExecutionReporter`. No Critical or Important findings. Two non-blocking Minor observations are recorded below: a pre-existing plugin-controlled report-field residual, and an evidence-diff omission of the untracked masker test file.

## What changed

Production diff is exactly two added strings in `src/Bukit-Core/Bukit.PluginHost/PluginSecretMasker.cs:5-15`:

```text
"COOKIE",
"AUTHORIZATION",
```

No other production file changed. `PluginExecutionReporter.cs` is the direct consumer and its masking calls are unchanged (`stderr` and free-text fields via `MaskText`; environment via `MaskEnvironment`). Tests added/extended:

- `tests/Bukit.PluginHost.Tests/PluginSecretMaskerTests.cs` — five new theory cases (`COOKIE`, `HTTP_COOKIE`, `AUTHORIZATION`, `HTTP_AUTHORIZATION`, lowercase `cookie`), plus `COOKIE` / `HTTP_AUTHORIZATION` entries and assertions in `MaskEnvironment_MasksOnlySecretKeys`.
- `tests/Bukit.PluginHost.Tests/PluginLockAndReportTests.cs` — `PluginExecutionReporter_MasksCookieAndAuthorizationValues` at line 209, which calls the real `PluginExecutionReporter.WriteAsync` and reads the written JSON. The other diff hunks in this file are earlier stage 9 CI-policy tests and are out of scope for I-01.

## 1. Correctness of the production change

| Check | Result | Evidence |
|---|---|---|
| Case-insensitive keys | Pass | `IsSecretKey` uses `StringComparison.OrdinalIgnoreCase` (`PluginSecretMasker.cs:49-50`); lowercase `cookie` theory case covers it. |
| Embedded `HTTP_` keys | Pass | Substring matching; `HTTP_COOKIE` and `HTTP_AUTHORIZATION` cases pass. Also covers `PROXY_AUTHORIZATION`, `SET_COOKIE`, etc. |
| Existing five fragments | Pass | `NOTION_TOKEN`, `API_KEY`, `PASSWORD`, `TOKEN`, `SECRET` remain; all five historical theory cases still pass; `MaskEnvironment` still masks `NOTION_TOKEN`/`API_KEY`. |
| Non-secret visibility | Pass | `PUBLIC_VALUE` remains `visible` in the report golden test; `MaskValue_LeavesNonSecretKeysUnchanged` and `MaskEnvironment_MasksOnlySecretKeys` cover non-secret keys. |
| Null/empty handling | Pass | `MaskValue` unchanged: null/empty returns `string.Empty`; existing null test still passes. |
| Minimality | Pass | Only two fragments added; no algorithm, schema, API, dependency, permission or config change. |
| Report path still writing plaintext env values | Host-controlled paths closed; one pre-existing plugin-controlled residual (S-01) | See audit below. |

### Report-path audit

`PluginExecutionReporter.WriteAsync` writes:

- `stderr` via `MaskText(report.Stderr, report.Environment)` — masked against raw environment values.
- `environment` via `MaskEnvironment(report.Environment)` — key-based masking; the two new fragments now produce `***` for `COOKIE`/`AUTHORIZATION`-containing keys, including `HTTP_*`.
- `diagnostics[].message` and `diagnostics[].path` via `MaskText` — masked.
- `artifacts[].description` via `MaskText` — masked.
- `permissions.environment.read` — key names only, not values; intentionally visible.
- Remaining metadata (`pluginId`, `operation`, `command`, `commandPath`, `entry`, `platform`, `requestId`, etc.) comes from the manifest/config/request, not from granted environment values.

The reporter passes the **raw** environment dictionary to `MaskText` (line 84), not the masked dictionary, so cookie/authorization values in stderr/diagnostics/artifact descriptions are still replaced. That ordering is correct.

Residual: `artifacts[].path` (line 186), `artifacts[].type`, `diagnostics[].code` (line 166) and `responseSummary.diagnosticCodes` are written raw. If a plugin deliberately echoes a granted cookie/authorization value into one of those fields, the report can still contain it. This is pre-existing, applies equally to `NOTION_TOKEN`/`API_KEY`/etc., and is outside the authorized key-fragment change; see S-01.

## 2. RED/GREEN evidence quality

**RED is behavioral, not a compile failure.** `R/red/tests.trx`:

- 28 executed, 21 passed, 7 failed, 0 skipped, 0 errors.
- Failures are exactly the new cases: five `MaskValue_MasksSecretKeyFragments` cases (`COOKIE`, `HTTP_COOKIE`, `AUTHORIZATION`, `HTTP_AUTHORIZATION`, `cookie`), `MaskEnvironment_MasksOnlySecretKeys`, and `PluginExecutionReporter_MasksCookieAndAuthorizationValues`.
- Failure messages are assertion failures (`Assert.Equal`, expected `***` actual `secret-value`; `Assert.Contains`, `"COOKIE": "***"` not found), so this is a behavioral RED.
- Existing `PluginExecutionReporter_WritesReportAndMasksSecrets` passed in RED, so the old report contract was preserved while the new behavior was absent.
- Timing supports test-first: test file mtime 22:10:26, RED TRX 22:10:55, production file mtime 22:10:59, focused GREEN 22:11:09, full GREEN 22:11:16.

**GREEN assertions are meaningful.** The report-level test does not merely call `MaskValue`:

```csharp
string path = await new PluginExecutionReporter().WriteAsync(directory.Path, report, CancellationToken.None);
string json = File.ReadAllText(path);
Assert.Contains("\"COOKIE\": \"***\"", json, StringComparison.Ordinal);
Assert.Contains("\"HTTP_AUTHORIZATION\": \"***\"", json, StringComparison.Ordinal);
Assert.DoesNotContain("session-cookie", json, StringComparison.Ordinal);
Assert.DoesNotContain("raw-token", json, StringComparison.Ordinal);
```

It exercises the real reporter, the real `MaskEnvironment` call and the written JSON. The exact-key assertions are what prove the new fragment behavior; the `DoesNotContain` assertions also cover the existing `MaskText` path. The golden report test continues to assert `PUBLIC_VALUE` visibility and the existing `NOTION_TOKEN` masking.

`R/focused-green/tests.trx`: 28/28 passed, 0 failed, 0 skipped.
`R/green/tests.trx`: 277/277 passed, 0 failed, 0 skipped. This is +6 tests versus the stage 9 final count of 271 (five new theory cases plus one report Fact), which is internally consistent.

Coverage (`R/coverage/`, `R/coverage-summary.json`): PluginHost 1521/1779 = 85.50%, up exactly 2 covered lines and 2 total lines from stage 9's 1519/1777. That matches the two new fragment lines and indicates both are covered. Abstractions remains 4986/5664 own and 4989/5664 merged, unchanged.

Cache (`R/cache/pluginhost-tests.json`, `R/cache/pluginhost-coverage.json`): both fingerprints match the current file hashes, HEAD, recorded command and SDK 10.0.100. Re-running the tool's `cache check` for both records returned `CACHE HIT` (fingerprints `609126...` and `0a8a28...`). Closure (`R/closure.json`) has no unmapped files; the direct consumer is `PluginExecutionReporter.cs`; changed files match the task. `git diff --check` is clean.

## 3. Schema, bytes, public API, permissions, unrelated behavior

- **Report schema**: unchanged; no schema file or writer field changed. The existing golden/schema test passes in the full GREEN run. The fixture contains no `COOKIE`/`AUTHORIZATION` keys, so existing report bytes are unchanged; only reports containing those key fragments change, and only the masked values change.
- **Public API**: no change. `PluginSecretMasker` is internal; its members and signatures are unchanged; only a private static array gained two entries. No public baseline/governance surface is affected.
- **Permissions config**: unchanged. `environment.read` validation/evaluator is untouched; granted key names remain visible in the `permissions` object, which is correct (names are not secrets).
- **Unrelated behavior**: none in production. `PluginSecretMasker` is only called by `PluginExecutionReporter`; the new fragments affect only `MaskValue`/`MaskEnvironment`, not execution, protocol, config loading or CLI behavior.

## 4. Over-masking risk

Over-masking is real but acceptable under the approved proposal, and is confined to report values:

- `COOKIE` matches `COOKIE_ENABLED`, `COOKIE_DOMAIN`, `COOKIE_PATH`, `COOKIE_SAMESITE`, `COOKIES`, `SET_COOKIE`, `HTTP_COOKIE`, etc.
- `AUTHORIZATION` matches `AUTHORIZATION_MODE`, `AUTHORIZATION_ENDPOINT`, `PROXY_AUTHORIZATION`, etc.

These non-secret configuration values become `***` in reports. There is no functional impact: masking is report-only, and the proposal explicitly prefers over-masking to a plaintext leak. No defect. A generic key such as `HTTP_HEADERS` whose *value* happens to contain a cookie header is not caught by key-based matching; that is consistent with the approved spec ("environment keys containing `COOKIE` or `AUTHORIZATION`") and is not a regression.

## 5. OpenSpec and plan accuracy

- `openspec/changes/fix-plugin-secret-masker-cookie-authorization/proposal.md` accurately describes the authorized behavior and scope. The worktree diff matches it: only the masker fragment list changed in production; no CLI, schema, permissions evaluator or config change.
- `specs/plugin-secret-masking/spec.md` matches the implementation: key-based, case-insensitive, includes `HTTP_COOKIE`/`HTTP_AUTHORIZATION`, preserves existing fragments and non-secret visibility.
- `tasks.md` still has all three items unchecked. Task 1 and task 2 are evidenced complete, but task 3 owns the backfill and final review; this is incomplete bookkeeping, not a false success claim.
- The stage 9 plan record still says `PARTIAL`, still describes I-01 as open, and still says the masker test covers "five fragments". After this authorized fix those statements are stale, but they were accurate for the stage 9 batch and are explicitly pending backfill in task 3. No false claim of completed ADR coverage was found. Backfill should update the I-01 paragraph and the "five fragments" row before the final delta review.

## 6. Earlier stage 9 Minor findings

M-01 (duplicate argument/option/runtime-command names throw raw `ArgumentException`), M-02 (`PluginHashVerifier` missing/unreadable file throws raw I/O), and M-03 (`MaskText` masks all environment values, contract undecided) remain open and are still correctly out of scope:

- No production diff touches `PluginCommandManifestValidator`, `PluginHashVerifier`, or `MaskText`.
- The I-01 fragment-list change does not resolve or worsen them.
- No fixes are required for this task.

## Findings

### Critical

None.

### Important

None.

### Minor

**S-01 — Pre-existing plugin-controlled report fields bypass text masking.**
`PluginExecutionReporter` masks `stderr`, diagnostic messages/paths and artifact descriptions, but writes `artifacts[].path` (`PluginExecutionReporter.cs:186`), `artifacts[].type`, `diagnostics[].code` (`:166`) and `responseSummary.diagnosticCodes` raw. A plugin that echoes a granted `COOKIE`/`AUTHORIZATION` value into one of those fields can still put plaintext in the report. This is not introduced by I-01 and applies equally to the existing secret fragments; it is outside the authorized key-fragment scope and does not block I-01. If ADR §22.3 is intended to be absolute for plugin-supplied report content, schedule a separate Core follow-up; do not expand this task.

**S-02 — `R/reviews/i01.diff` omits the untracked masker test file.**
The diff contains only `src/Bukit-Core/Bukit.PluginHost/PluginSecretMasker.cs` and `tests/Bukit.PluginHost.Tests/PluginLockAndReportTests.cs`. The new/untracked `tests/Bukit.PluginHost.Tests/PluginSecretMaskerTests.cs` — which carries the five new theory cases and the two `MaskEnvironment` entries — is not in the diff. It is present in `R/closure.json`, its hash (`d358a9...`) is in both cache records, and both GREEN TRX files list its new cases, so the evidence is verifiable; but the diff artifact is incomplete for a reviewer who relies on it. Include the untracked file when generating the final-delta diff. No code change required.

## Commands and evidence reviewed

```sh
# Full PluginHost GREEN (recorded command)
dotnet test tests/Bukit.PluginHost.Tests/Bukit.PluginHost.Tests.csproj -c Release \
  --logger "trx;LogFileName=tests.trx" \
  --results-directory "$R/green"
# -> 277 passed / 0 failed / 0 skipped

# PluginHost coverage (recorded command)
dotnet test tests/Bukit.PluginHost.Tests/Bukit.PluginHost.Tests.csproj -c Release \
  --collect:"XPlat Code Coverage" \
  --logger "trx;LogFileName=tests.trx" \
  --results-directory "$R/coverage"
# -> 277 passed; PluginHost 1521/1779 = 85.50%

# Review verification (read-only)
python3 scripts/checks/codex-workflow.py cache check ...   # 2/2 CACHE HIT
git diff --check                                           # clean
```

Focused RED/GREEN runs covered `PluginSecretMaskerTests` and `PluginLockAndReportTests` (28 tests). RED: 7 failed / 21 passed / 0 skipped. Focused GREEN: 28/28. The reviewer did not rerun `dotnet test`; the TRX files, logs, file hashes and cache records were verified directly.
